from django.contrib.auth.models import User, Group
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import HttpResponse
from .models import WorkRecord

from datetime import date
import json
import re
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import Group
from django.db.models import Sum
from django.db.models import Count
from django.contrib.auth import update_session_auth_hash

from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Paragraph
)
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
def login_user(request):

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            return redirect("/")

        messages.error(request, "Invalid Username or Password")

    return render(request, "calculator/login.html")


def logout_user(request):
    logout(request)
    return redirect("/login/")


# ==========================================
# HOME
# ==========================================
@login_required(login_url="/login/")
def index(request):

    if request.method == "POST":

        WorkRecord.objects.create(
            date=request.POST.get("date"),
            operator=request.POST.get("operator"),
            machine=request.POST.get("machine"),
            site=request.POST.get("site"),
            start_time=request.POST.get("start_time"),
            end_time=request.POST.get("end_time"),
            total_time=request.POST.get("total_time"),
            break_time=request.POST.get("break_time"),
            working_time=request.POST.get("working_time"),
        )

        messages.success(request, "✅ Record Saved Successfully!")

        return redirect("/")

    return render(request, "calculator/index.html")

# ==========================================
# HISTORY
# ==========================================
@login_required(login_url="/login/")
def history(request):

    records = WorkRecord.objects.all().order_by("-id")

    search = request.GET.get("search", "").strip()
    from_date = request.GET.get("from_date", "")
    to_date = request.GET.get("to_date", "")

    if search:
        records = records.filter(operator__icontains=search)

    if from_date:
        records = records.filter(date__gte=from_date)

    if to_date:
        records = records.filter(date__lte=to_date)

    # -----------------------------
    # Dashboard Totals
    # -----------------------------

    total_work_minutes = 0
    total_break_minutes = 0

    for record in records:

        work = re.findall(r"\d+", record.working_time)

        if len(work) >= 2:
            total_work_minutes += (
                int(work[0]) * 60 +
                int(work[1])
            )

        br = re.findall(r"\d+", record.break_time)

        if len(br) >= 2:
            total_break_minutes += (
                int(br[0]) * 60 +
                int(br[1])
            )

    total_work_hours = total_work_minutes // 60
    total_work_minutes = total_work_minutes % 60

    total_break_hours = total_break_minutes // 60
    total_break_minutes = total_break_minutes % 60

    # -----------------------------
    # Chart Data
    # -----------------------------

    chart_labels = []
    chart_data = []

    for record in records:

        chart_labels.append(record.operator)

        numbers = re.findall(r"\d+", record.working_time)

        if len(numbers) >= 2:

            hrs = int(numbers[0])
            mins = int(numbers[1])

            chart_data.append(
                round(hrs + mins / 60, 2)
            )

        else:

            chart_data.append(0)

    context = {

        "records": records,

        "search": search,

        "from_date": from_date,

        "to_date": to_date,

        "total_work_hours": total_work_hours,
        "total_work_minutes": total_work_minutes,

        "total_break_hours": total_break_hours,
        "total_break_minutes": total_break_minutes,

        "chart_labels": json.dumps(chart_labels),
        "chart_data": json.dumps(chart_data),

    }

    return render(
        request,
        "calculator/history.html",
        context
    )


# ==========================================
# DELETE RECORD
# ==========================================
@login_required(login_url="/login/")
def delete_record(request, id):

    record = get_object_or_404(
        WorkRecord,
        id=id
    )

    record.delete()

    messages.success(
        request,
        "🗑 Record Deleted Successfully!"
    )

    return redirect("/history/")


# ==========================================
# EDIT RECORD
# ==========================================
@login_required(login_url="/login/")
def edit_record(request, id):

    record = get_object_or_404(
        WorkRecord,
        id=id
    )

    if request.method == "POST":

        record.date = request.POST.get("date")
        record.operator = request.POST.get("operator")
        record.machine = request.POST.get("machine")
        record.site = request.POST.get("site")
        record.start_time = request.POST.get("start_time")
        record.end_time = request.POST.get("end_time")
        record.total_time = request.POST.get("total_time")
        record.break_time = request.POST.get("break_time")
        record.working_time = request.POST.get("working_time")

        record.save()

        messages.success(
            request,
            "✅ Record Updated Successfully!"
        )

        return redirect("/history/")

    return render(
        request,
        "calculator/edit.html",
        {
            "record": record
        }
    )


# ==========================================
# EXPORT PDF
# ==========================================
@login_required(login_url="/login/")
def export_pdf(request):

    response = HttpResponse(
        content_type="application/pdf"
    )

    response[
        "Content-Disposition"
    ] = 'attachment; filename="JCB_Work_Records.pdf"'

    doc = SimpleDocTemplate(response)

    styles = getSampleStyleSheet()

    elements = []

    elements.append(
        Paragraph(
            "<b><font size=18>JCB Work Records</font></b>",
            styles["Title"]
        )
    )

    data = [[
        "ID",
        "Date",
        "Operator",
        "Machine",
        "Site",
        "Start",
        "End",
        "Total",
        "Break",
        "Working"
    ]]

    records = WorkRecord.objects.all().order_by("-id")

    for record in records:

        data.append([
            record.id,
            str(record.date),
            record.operator,
            record.machine,
            record.site,
            str(record.start_time),
            str(record.end_time),
            record.total_time,
            record.break_time,
            record.working_time,
        ])

    table = Table(data)

    table.setStyle(TableStyle([

        ("BACKGROUND", (0,0), (-1,0), colors.green),

        ("TEXTCOLOR", (0,0), (-1,0), colors.white),

        ("GRID", (0,0), (-1,-1), 1, colors.black),

        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),

        ("ALIGN", (0,0), (-1,-1), "CENTER"),

        ("BOTTOMPADDING", (0,0), (-1,0), 10),

        ("BACKGROUND", (0,1), (-1,-1), colors.beige)

    ]))

    elements.append(table)

    doc.build(elements)

    return response

# ==========================================
# EXPORT EXCEL
# ==========================================
@login_required(login_url="/login/")
def export_excel(request):

    workbook = Workbook()

    sheet = workbook.active
    sheet.title = "JCB Work Records"

    sheet.append([
        "ID",
        "Date",
        "Operator",
        "Machine",
        "Site",
        "Start Time",
        "End Time",
        "Total Time",
        "Break Time",
        "Working Time"
    ])

    # Header Style
    header_fill = PatternFill(
        start_color="198754",
        end_color="198754",
        fill_type="solid"
    )

    header_font = Font(
        bold=True,
        color="FFFFFF"
    )

    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")

    records = WorkRecord.objects.all().order_by("-id")

    for record in records:

        sheet.append([
            record.id,
            str(record.date),
            record.operator,
            record.machine,
            record.site,
            str(record.start_time),
            str(record.end_time),
            record.total_time,
            record.break_time,
            record.working_time
        ])

    # Auto Width
    for column in sheet.columns:

        max_length = 0

        column_letter = get_column_letter(column[0].column)

        for cell in column:

            if cell.value:

                max_length = max(
                    max_length,
                    len(str(cell.value))
                )

        sheet.column_dimensions[column_letter].width = max_length + 3

    sheet.freeze_panes = "A2"

    sheet.auto_filter.ref = sheet.dimensions

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

    response["Content-Disposition"] = (
        'attachment; filename="JCB_Work_Records.xlsx"'
    )

    workbook.save(response)

    return response


# ==========================================
# DASHBOARD
# ==========================================
from django.db.models import Count
from datetime import date
import json

# ==========================================
# DASHBOARD
# ==========================================
@login_required(login_url="/login/")
def dashboard(request):

    # Total Counts
    total_records = WorkRecord.objects.count()

    total_operators = (
        WorkRecord.objects.values("operator")
        .distinct()
        .count()
    )

    total_machines = (
        WorkRecord.objects.values("machine")
        .distinct()
        .count()
    )

    today_records = WorkRecord.objects.filter(
        date=date.today()
    ).count()

    # Latest Records
    latest_records = (
        WorkRecord.objects
        .all()
        .order_by("-id")[:5]
    )

    # Operator Chart
    operator_chart = (
        WorkRecord.objects
        .values("operator")
        .annotate(total=Count("id"))
        .order_by("operator")
    )

    labels = []
    data = []

    for item in operator_chart:
        labels.append(item["operator"])
        data.append(item["total"])

    context = {

        "total_records": total_records,

        "total_operators": total_operators,

        "total_machines": total_machines,

        "today_records": today_records,

        "latest_records": latest_records,

        "labels": json.dumps(labels),

        "data": json.dumps(data),

    }

    return render(
        request,
        "calculator/dashboard.html",
        context
    )
@login_required(login_url="/login/")
def users(request):

    if request.user.groups.filter(name="Admin").exists():
        users = User.objects.all().order_by("id")
    else:
        users = User.objects.filter(id=request.user.id)

    return render(request, "calculator/users.html", {
        "users": users
    })
@login_required(login_url="/login/")
def add_user(request):

    if request.method == "POST":

        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")
        role = request.POST.get("role")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists!")
            return redirect("/users/")

        user = User.objects.create(
            username=username,
            email=email,
            password=make_password(password)
        )

        group = Group.objects.get(name=role)
        user.groups.add(group)

        messages.success(request, "✅ New User Created Successfully!")

        return redirect("/users/")

    return render(request, "calculator/add_user.html")
@login_required(login_url="/login/")
def edit_user(request, id):

    user = User.objects.get(id=id)

    if request.method == "POST":

        user.username = request.POST.get("username")
        user.email = request.POST.get("email")

        user.save()

        messages.success(request, "✅ User Updated Successfully!")

        return redirect("/users/")

    return render(request, "calculator/edit_user.html", {
        "user": user
    })
@login_required(login_url="/login/")
def delete_user(request, id):

    user = User.objects.get(id=id)

    user.delete()

    messages.success(request, "🗑 User Deleted Successfully!")

    return redirect("/users/")
@login_required(login_url="/login/")
def reset_password(request, id):

    user = User.objects.get(id=id)

    if request.method == "POST":

        new_password = request.POST.get("password")

        user.password = make_password(new_password)

        user.save()

        messages.success(request, "✅ Password Changed Successfully!")

        return redirect("/users/")

    return render(request, "calculator/reset_password.html", {
        "user": user
    })
@login_required(login_url="/login/")
def profile(request):

    role = "Operator"

    if request.user.groups.filter(name="Admin").exists():
        role = "Admin"

    context = {
        "user": request.user,
        "role": role,
    }

    return render(request, "calculator/profile.html", context)
@login_required(login_url="/login/")
def edit_profile(request):

    if request.method == "POST":

        request.user.username = request.POST.get("username")
        request.user.email = request.POST.get("email")

        request.user.save()

        messages.success(request, "✅ Profile Updated Successfully!")

        return redirect("/profile/")

    return render(request, "calculator/edit_profile.html")
from django.contrib.auth import update_session_auth_hash

@login_required(login_url="/login/")
def change_password(request):

    if request.method == "POST":

        old_password = request.POST.get("old_password")
        new_password = request.POST.get("new_password")
        confirm_password = request.POST.get("confirm_password")

        if not request.user.check_password(old_password):
            messages.error(request, "Current Password is incorrect.")
            return redirect("/change-password/")

        if new_password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return redirect("/change-password/")

        request.user.set_password(new_password)
        request.user.save()

        update_session_auth_hash(request, request.user)

        messages.success(request, "Password Changed Successfully.")

        return redirect("/profile/")

    return render(request, "calculator/change_password.html")
@login_required(login_url="/login/")
def change_password(request):

    if request.method == "POST":

        current = request.POST.get("current")
        new = request.POST.get("new")
        confirm = request.POST.get("confirm")

        if not request.user.check_password(current):
            messages.error(request, "Current Password is Wrong.")
            return redirect("/change-password/")

        if new != confirm:
            messages.error(request, "New Password & Confirm Password do not match.")
            return redirect("/change-password/")

        request.user.set_password(new)
        request.user.save()

        update_session_auth_hash(request, request.user)

        messages.success(request, "Password Changed Successfully.")

        return redirect("/profile/")

    return render(request, "calculator/change_password.html")